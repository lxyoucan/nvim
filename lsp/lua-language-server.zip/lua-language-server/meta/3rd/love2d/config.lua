name    = 'LÖVE'
words   = {'love%.%w+'}
configs = {
    {
        key    = 'Lua.runtime.version',
        action = 'set',
        value  = 'LuaJIT',
    },
}