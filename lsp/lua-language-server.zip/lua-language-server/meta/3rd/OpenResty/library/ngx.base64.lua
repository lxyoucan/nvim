---@meta
ngx_base64={}
function ngx_base64.encode_base64url(s) end
function ngx_base64.decode_base64url(s) end
ngx_base64.version="0.1.17"
return ngx_base64