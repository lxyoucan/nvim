---@meta
resty_signal={}
function resty_signal.kill(pid, sig) end
function resty_signal.signum(name) end
resty_signal.version=0.02
return resty_signal