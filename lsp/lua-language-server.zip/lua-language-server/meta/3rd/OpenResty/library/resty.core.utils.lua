---@meta
resty_core_utils={}
function resty_core_utils.str_replace_char(str, find, replace) end
resty_core_utils.version="0.1.17"
return resty_core_utils