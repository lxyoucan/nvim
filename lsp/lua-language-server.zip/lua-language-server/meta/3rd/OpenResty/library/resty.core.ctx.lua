---@meta
resty_core_ctx={}
resty_core_ctx._VERSION="0.1.17"
return resty_core_ctx