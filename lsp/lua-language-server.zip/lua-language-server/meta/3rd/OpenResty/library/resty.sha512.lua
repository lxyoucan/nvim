---@meta
resty_sha512={}
function resty_sha512.final(self) end
function resty_sha512.new(self) end
function resty_sha512.reset(self) end
resty_sha512._VERSION="0.11"
function resty_sha512.update(self, s) end
return resty_sha512