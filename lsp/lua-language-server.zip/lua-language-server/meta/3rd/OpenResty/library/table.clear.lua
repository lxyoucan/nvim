---@meta
function table_clear() end
return table_clear