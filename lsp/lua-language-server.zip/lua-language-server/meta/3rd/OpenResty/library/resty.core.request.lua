---@meta
resty_core_request={}
resty_core_request.version="0.1.17"
return resty_core_request