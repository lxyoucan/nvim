---@meta
resty_string={}
function resty_string.to_hex(s) end
resty_string._VERSION="0.11"
function resty_string.atoi(s) end
return resty_string