---@meta
resty_core={}
resty_core.version="0.1.17"
return resty_core