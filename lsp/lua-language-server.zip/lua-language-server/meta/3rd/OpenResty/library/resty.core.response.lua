---@meta
resty_core_response={}
function resty_core_response.set_resp_header() end
resty_core_response.version="0.1.17"
return resty_core_response