---@meta
ngx_process={}
function ngx_process.get_master_pid() end
function ngx_process.enable_privileged_agent() end
function ngx_process.type() end
function ngx_process.signal_graceful_exit() end
ngx_process.version="0.1.17"
return ngx_process