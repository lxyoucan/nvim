---@meta
resty_core_uri={}
resty_core_uri.version="0.1.17"
return resty_core_uri