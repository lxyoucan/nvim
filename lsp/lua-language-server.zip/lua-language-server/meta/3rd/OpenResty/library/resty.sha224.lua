---@meta
resty_sha224={}
function resty_sha224.final(self) end
function resty_sha224.new(self) end
function resty_sha224.reset(self) end
resty_sha224._VERSION="0.11"
function resty_sha224.update(self, s) end
return resty_sha224