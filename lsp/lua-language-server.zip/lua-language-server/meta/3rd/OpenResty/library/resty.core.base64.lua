---@meta
resty_core_base64={}
resty_core_base64.version="0.1.17"
return resty_core_base64