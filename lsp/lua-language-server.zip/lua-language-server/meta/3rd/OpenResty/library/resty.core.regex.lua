---@meta
resty_core_regex={}
function resty_core_regex.collect_captures() end
function resty_core_regex.set_buf_grow_ratio(ratio) end
function resty_core_regex.re_sub_compile() end
function resty_core_regex.is_regex_cache_empty() end
function resty_core_regex.check_buf_size() end
function resty_core_regex.re_match_compile() end
function resty_core_regex.destroy_compiled_regex() end
resty_core_regex.version="0.1.17"
return resty_core_regex