---@meta
ngx_resp={}
function ngx_resp.add_header(key, value) end
ngx_resp.version="0.1.17"
return ngx_resp