---@meta
resty_random={}
resty_random._VERSION="0.11"
function resty_random.bytes(len, strong) end
return resty_random