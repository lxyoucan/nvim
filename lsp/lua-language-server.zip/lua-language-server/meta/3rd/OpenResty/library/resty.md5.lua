---@meta
resty_md5={}
function resty_md5.final(self) end
function resty_md5.new(self) end
function resty_md5.reset(self) end
resty_md5._VERSION="0.11"
function resty_md5.update(self, s) end
return resty_md5