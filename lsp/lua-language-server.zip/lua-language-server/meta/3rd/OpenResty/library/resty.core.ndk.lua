---@meta
resty_core_ndk={}
resty_core_ndk.version="0.1.17"
return resty_core_ndk