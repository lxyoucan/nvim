---@meta
resty_sha1={}
function resty_sha1.final(self) end
function resty_sha1.new(self) end
function resty_sha1.reset(self) end
resty_sha1._VERSION="0.11"
function resty_sha1.update(self, s) end
return resty_sha1