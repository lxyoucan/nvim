---@meta
resty_core_var={}
resty_core_var.version="0.1.17"
return resty_core_var