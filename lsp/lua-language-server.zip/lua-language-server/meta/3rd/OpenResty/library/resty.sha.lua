---@meta
resty_sha={}
resty_sha._VERSION="0.11"
return resty_sha