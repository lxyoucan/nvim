---@meta
resty_core_shdict={}
resty_core_shdict.version="0.1.17"
return resty_core_shdict