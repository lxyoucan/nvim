---@meta
resty_core_worker={}
resty_core_worker._VERSION="0.1.17"
return resty_core_worker