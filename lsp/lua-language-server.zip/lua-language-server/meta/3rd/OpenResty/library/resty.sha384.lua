---@meta
resty_sha384={}
function resty_sha384.final(self) end
function resty_sha384.new(self) end
function resty_sha384.reset(self) end
resty_sha384._VERSION="0.11"
function resty_sha384.update(self, s) end
return resty_sha384