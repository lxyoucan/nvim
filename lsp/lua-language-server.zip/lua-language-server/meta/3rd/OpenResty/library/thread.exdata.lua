---@meta
function thread_exdata() end
return thread_exdata