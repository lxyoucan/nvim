---@meta
tablepool={}
function tablepool.release(tag, obj, noclear) end
function tablepool.fetch(tag, narr, nrec) end
return tablepool