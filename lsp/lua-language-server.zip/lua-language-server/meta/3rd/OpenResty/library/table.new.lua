---@meta
function table_new() end
return table_new