---@meta
resty_core_exit={}
resty_core_exit.version="0.1.17"
return resty_core_exit