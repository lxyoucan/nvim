---@meta
ngx_re={}
function ngx_re.opt(option, value) end
function ngx_re.split(subj, regex, opts, ctx, max, res) end
ngx_re.version="0.1.17"
return ngx_re