---@meta
ngx_pipe={}
ngx_pipe._gc_ref_c_opt="-c"
function ngx_pipe.spawn() end
ngx_pipe.version="0.1.17"
return ngx_pipe