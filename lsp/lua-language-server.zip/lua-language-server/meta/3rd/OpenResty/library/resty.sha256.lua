---@meta
resty_sha256={}
function resty_sha256.final(self) end
function resty_sha256.new(self) end
function resty_sha256.reset(self) end
resty_sha256._VERSION="0.11"
function resty_sha256.update(self, s) end
return resty_sha256