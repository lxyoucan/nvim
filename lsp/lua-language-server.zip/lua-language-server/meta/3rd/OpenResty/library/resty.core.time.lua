---@meta
resty_core_time={}
resty_core_time.version="0.1.17"
return resty_core_time