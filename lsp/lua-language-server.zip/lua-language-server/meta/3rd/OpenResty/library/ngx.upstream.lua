---@meta
ngx_upstream={}
function ngx_upstream.get_backup_peers() end
function ngx_upstream.get_servers() end
function ngx_upstream.current_upstream_name() end
function ngx_upstream.get_primary_peers() end
function ngx_upstream.set_peer_down() end
function ngx_upstream.get_upstreams() end
return ngx_upstream