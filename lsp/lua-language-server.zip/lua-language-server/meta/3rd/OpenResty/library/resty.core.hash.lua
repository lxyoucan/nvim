---@meta
resty_core_hash={}
resty_core_hash.version="0.1.17"
return resty_core_hash