---@meta
resty_shell={}
function resty_shell.run(cmd, stdin, timeout, max_size) end
resty_shell.version=0.01
return resty_shell