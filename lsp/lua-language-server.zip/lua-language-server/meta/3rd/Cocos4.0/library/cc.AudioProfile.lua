---@meta

---@class cc.AudioProfile 
local AudioProfile={ }
cc.AudioProfile=AudioProfile




---* Default constructor<br>
---* lua new
---@return self
function AudioProfile:AudioProfile () end