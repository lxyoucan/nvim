---@meta

---
---
---
---[View documents](http://www.lua.org/manual/5.4/manual.html#pdf-table)
---
---@class tablelib
table = {}

---
---Given a list where all elements are strings or numbers, returns the string `list[i]..sep..list[i+1] ··· sep..list[j]`.
---
---[View documents](http://www.lua.org/manual/5.4/manual.html#pdf-table.concat)
---
---@param list table
---@param sep? string
---@param i?   integer
---@param j?   integer
---@return string
function table.concat(list, sep, i, j) end

---
---Inserts element `value` at position `pos` in `list`.
---
---[View documents](http://www.lua.org/manual/5.4/manual.html#pdf-table.insert)
---
---@overload fun(list: table, value: any)
---@param list table
---@param pos integer
---@param value any
function table.insert(list, pos, value) end

---@version <5.1
---
---Returns the largest positive numerical index of the given table, or zero if the table has no positive numerical indices.
---
---[View documents](http://www.lua.org/manual/5.4/manual.html#pdf-table.maxn)
---
---@param table table
---@return integer
function table.maxn(table) end

---@version >5.3
---
---Moves elements from table `a1` to table `a2`.
---```lua
---a2[t],··· = a1[f],···,a1[e]
---return a2
---```
---
---
---[View documents](http://www.lua.org/manual/5.4/manual.html#pdf-table.move)
---
---@param a1  table
---@param f   integer
---@param e   integer
---@param t   integer
---@param a2? table
---@return table a2
function table.move(a1, f, e, t, a2) end

---@version >5.2, JIT
---
---Returns a new table with all arguments stored into keys `1`, `2`, etc. and with a field `"n"` with the total number of arguments.
---
---[View documents](http://www.lua.org/manual/5.4/manual.html#pdf-table.pack)
---
---@return table
function table.pack(...) end

---
---Removes from `list` the element at position `pos`, returning the value of the removed element.
---
---[View documents](http://www.lua.org/manual/5.4/manual.html#pdf-table.remove)
---
---@param list table
---@param pos? integer
---@return any
function table.remove(list, pos) end

---
---Sorts list elements in a given order, *in-place*, from `list[1]` to `list[#list]`.
---
---[View documents](http://www.lua.org/manual/5.4/manual.html#pdf-table.sort)
---
---@param list table
---@param comp fun(a: any, b: any):boolean
function table.sort(list, comp) end

---@version >5.2, JIT
---
---Returns the elements from the given list. This function is equivalent to
---```lua
---    return list[i], list[i+1], ···, list[j]
---```
---By default, `i` is `1` and `j` is `#list`.
---
---
---[View documents](http://www.lua.org/manual/5.4/manual.html#pdf-table.unpack)
---
---@param list table
---@param i?   integer
---@param j?   integer
function table.unpack(list, i, j) end

return table
